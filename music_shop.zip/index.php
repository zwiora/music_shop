<!doctype html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ad libitum</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="style/main.css">
</head>
<body>

<header>
    <h1>
        <a href="#">Ad libitum</a>
    </h1>
    <nav>
        <a href="#">home</a>
        <a href="#">discover</a>
        <label for="search">
            <input id="search" type="text">
            <button><i class="fas fa-search"></i></button>
        </label>
        <a href="#" class="basket">
            <i class="fas fa-shopping-cart"></i>
            1
        </a>
    </nav>
</header>
<main>
    <figure>
        <!--            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">-->
        <!--                <div class="carousel-inner">-->
        <!--                    <div class="carousel-item active">-->
        <!--                        <img class="d-block w-100" src="img/piano.jpg" alt="First slide">-->
        <!--                    </div>-->
        <!--                    <div class="carousel-item">-->
        <!--                        <img class="d-block w-100" src="img/piano.jpg" alt="Second slide">-->
        <!--                    </div>-->
        <!--                    <div class="carousel-item">-->
        <!--                        <img class="d-block w-100" src="img/piano.jpg" alt="Third slide">-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--                <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">-->
        <!--                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>-->
        <!--                    <span class="sr-only">Previous</span>-->
        <!--                </a>-->
        <!--                <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">-->
        <!--                    <span class="carousel-control-next-icon" aria-hidden="true"></span>-->
        <!--                    <span class="sr-only">Next</span>-->
        <!--                </a>-->
        <!--            </div>-->
        <a href="#">Discover</a>
    </figure>
    <section class="most_popular">
        <h2>Most popular</h2>
        <article>
            <a href="#" class="product_short">
                <figure><img src="img/product/we_are_the_world.png" alt="scores">
                    <figcaption>
                        <h3>We are the world</h3>
                        <h4>by Lionel Richie & Michael Jackson</h4>
                        <h4>piano - intermediate</h4>
                        <p>15,99zł</p>
                    </figcaption>
                </figure>
            </a>
            <a href="#" class="product_short">
                <figure><img src="img/product/we_are_the_world.png" alt="scores">
                    <figcaption>
                        <h3>We are the world</h3>
                        <h4>by Lionel Richie & Michael Jackson</h4>
                        <h4>piano - intermediate</h4>
                        <p>15,99zł</p>
                    </figcaption>
                </figure>
            </a>
            <a href="#" class="product_short">
                <figure><img src="img/product/we_are_the_world.png" alt="scores">
                    <figcaption>
                        <h3>We are the world</h3>
                        <h4>by Lionel Richie & Michael Jackson</h4>
                        <h4>piano - intermediate</h4>
                        <p>15,99zł</p>
                    </figcaption>
                </figure>
            </a>
        </article>
    </section>
    <section class="our_favourite">
        <h2>Our favourite</h2>
        <article>
            <a href="#" class="product_short">
                <figure><img src="img/product/we_are_the_world.png" alt="scores">
                    <figcaption>
                        <h3>We are the world</h3>
                        <h4>by Lionel Richie & Michael Jackson</h4>
                        <h4>piano - intermediate</h4>
                        <p>15,99zł</p>
                    </figcaption>
                </figure>
            </a>
            <a href="#" class="product_short">
                <figure><img src="img/product/we_are_the_world.png" alt="scores">
                    <figcaption>
                        <h3>We are the world</h3>
                        <h4>by Lionel Richie & Michael Jackson</h4>
                        <h4>piano - intermediate</h4>
                        <p>15,99zł</p>
                    </figcaption>
                </figure>
            </a>
            <a href="#" class="product_short">
                <figure><img src="img/product/we_are_the_world.png" alt="scores">
                    <figcaption>
                        <h3>We are the world</h3>
                        <h4>by Lionel Richie & Michael Jackson</h4>
                        <h4>piano - intermediate</h4>
                        <p>15,99zł</p>
                    </figcaption>
                </figure>
            </a>
        </article>

    </section>
    <section class="new_sheets">
        <h2>New sheets </h2>
        <article>
            <a href="#" class="product_short">
                <figure><img src="img/product/we_are_the_world.png" alt="scores">
                    <figcaption>
                        <h3>We are the world</h3>
                        <h4>by Lionel Richie & Michael Jackson</h4>
                        <h4>piano - intermediate</h4>
                        <p>15,99zł</p>
                    </figcaption>
                </figure>
            </a>
            <a href="#" class="product_short">
                <figure><img src="img/product/we_are_the_world.png" alt="scores">
                    <figcaption>
                        <h3>We are the world</h3>
                        <h4>by Lionel Richie & Michael Jackson</h4>
                        <h4>piano - intermediate</h4>
                        <p>15,99zł</p>
                    </figcaption>
                </figure>
            </a>
            <a href="#" class="product_short">
                <figure><img src="img/product/we_are_the_world.png" alt="scores">
                    <figcaption>
                        <h3>We are the world</h3>
                        <h4>by Lionel Richie & Michael Jackson</h4>
                        <h4>piano - intermediate</h4>
                        <p>15,99zł</p>
                    </figcaption>
                </figure>
            </a>
        </article>
    </section>
</main>
<footer>
    <a href="https://www.facebook.com/"><i class="fab fa-facebook"></i></a>
    <a href="https://www.instagram.com/"><i class="fab fa-instagram"></i></a>
    <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a>
    <a href="https://pl.pinterest.com/"><i class="fab fa-pinterest"></i></a>
    <p>contact@adlibitum.com</p>
    <h4>&copy; Wiora 2020</h4>
</footer>
<script src="https://kit.fontawesome.com/d189ad460d.js" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
        integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
        crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
        crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
        crossorigin="anonymous"></script>
</body>
</html>
